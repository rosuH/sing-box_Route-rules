# 🗣
#### The file here is the original data file that can be used by sing-box1.8.0⁺ version after successful conversion.